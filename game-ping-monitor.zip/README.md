# Ultimate Game Ping Monitor

A native Android application built with **Kotlin** and **Jetpack Compose** that measures your smartphone's real-time internet latency, jitter, packet loss, and active network type (`5G`, `4G LTE`, `3G`, `Wi-Fi`) — featuring an always-on-top **Floating Gaming Overlay** that stays visible over **eFootball**, **8 Ball Pool**, **PUBG Mobile**, **Free Fire**, and other full-screen Android games.

> **Important Measurement Scope:** This app measures real-time internet latency between your device and reliable public anycast test endpoints (such as `1.1.1.1`, `8.8.8.8`, `9.9.9.9`, or `208.67.222.222`). It monitors your active internet connection quality rather than internal game-server ping.

---

## Key Features

- **1-Second Real-Time Ping Engine:** Uses monotonic nanosecond timing (`SystemClock.elapsedRealtimeNanos`) with TCP socket handshakes (and optional ICMP Echo with automatic TCP fallback) to measure real latency every 1 second. Never generates fake or randomized values.
- **Session Statistics & Stability Analysis:** Calculates live **Current**, **Min**, **Max**, and **Average** ping, consecutive-sample **Jitter (ms)**, **Packet Loss (%)**, and classifies stability into `EXCELLENT`, `GOOD`, `UNSTABLE`, `HIGH LATENCY`, or `DISCONNECTED`.
- **Automatic Network Switching Detection:** Uses `ConnectivityManager.NetworkCallback` and `TelephonyManager` (`DisplayInfoListener`) to automatically detect `5G`, `4G LTE`, `3G`, `2G`, `Wi-Fi`, `Ethernet`, or `Disconnected` states in real time.
- **Always-On-Top Floating Gaming Overlay (`SYSTEM_ALERT_WINDOW`):**
  - Movable anywhere on screen via drag gestures (with position clamping across portrait and landscape rotation).
  - Adjustable widget size (`75%`–`135%`) and transparency (`35%`–`100%`).
  - Minimized compact pill & expanded telemetry HUD (`PING`, `JITTER`, `PACKET LOSS`, `NETWORK`, `STATUS`).
  - Start/Pause monitoring, Lock Position, and Close controls directly on the overlay and in the foreground notification.
- **Battery-Conscious Foreground Service:** Runs as an Android 14+ compliant `specialUse` foreground service with a low-priority silent notification and skips network probing automatically when offline.

---

## Project Structure

- `app/src/main/java/com/example/model/PingModels.kt` — Domain models, presets, and `PingMetricsCalculator`
- `app/src/main/java/com/example/network/NetworkMonitor.kt` — `ConnectivityManager` & `TelephonyManager` network state observer
- `app/src/main/java/com/example/network/PingProber.kt` — Real TCP handshake & ICMP latency prober
- `app/src/main/java/com/example/network/PingMonitorRepository.kt` — 1s monitoring loop & DataStore preferences
- `app/src/main/java/com/example/service/PingOverlayService.kt` — Foreground service hosting `WindowManager` + `ComposeView` HUD
- `app/src/main/java/com/example/ui/` — Gaming theme, `PingGauge`, `LatencyChart`, `OverlayHudCard`, and screens
- `.github/workflows/android-build.yml` — Automated GitHub Actions Debug APK build pipeline

---

## How to Build the Debug APK Locally

### Prerequisites
- **JDK 17**
- **Android SDK** (Compile SDK 36, Build Tools 35+/36)
- **Gradle 9.3.1** (or Android Studio Meerkat / Narwhal+)

### Commands

1. Restore the debug signing keystore (if `debug.keystore` is not already present):
   ```bash
   base64 -d debug.keystore.base64 > debug.keystore
   ```
2. Run unit & Robolectric tests:
   ```bash
   gradle :app:testDebugUnitTest
   ```
3. Build the Debug APK:
   ```bash
   gradle :app:assembleDebug
   ```
4. Locate the generated APK at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

---

## How to Download the APK from GitHub Actions

1. Push this repository to GitHub.
2. Open the **Actions** tab in your GitHub repository.
3. Select the **Android Debug APK Build** workflow (it runs automatically on push/PR to `main`/`master`, or manually via **Run workflow**).
4. Once the build finishes, scroll down to the **Artifacts** section of the workflow run.
5. Click **`ultimate-game-ping-monitor-debug-apk`** to download the ZIP containing `app-debug.apk`.
6. Extract `app-debug.apk` from the downloaded ZIP archive.

---

## How to Install on an Android Smartphone

1. Transfer `app-debug.apk` to your Android phone (or download it directly on the phone from GitHub Actions).
2. Tap `app-debug.apk` in your phone's **Files** app.
3. If prompted, enable **Allow from this source** / **Install unknown apps** for your browser or file manager.
4. Tap **Install**, then open **Game Ping Monitor**.
5. Grant the requested permissions when launching the overlay:
   - **Display over other apps** (`SYSTEM_ALERT_WINDOW`) for the floating gaming HUD.
   - **Notifications** (Android 13+) for foreground service controls.
   - **Phone State** (optional) to distinguish `5G`, `4G LTE`, and `3G` mobile networks.
6. Tap **Launch HUD**, then open **eFootball**, **8 Ball Pool**, **PUBG Mobile**, **Free Fire**, or any other Android game.
