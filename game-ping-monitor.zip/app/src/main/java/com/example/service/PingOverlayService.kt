package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.PingMonitorApplication
import com.example.R
import com.example.model.PingMetrics
import com.example.network.PingMonitorRepository
import com.example.ui.components.OverlayHudCard
import com.example.ui.theme.GamePingTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class PingOverlayService : Service() {

    private lateinit var repository: PingMonitorRepository
    private lateinit var windowManager: WindowManager
    private lateinit var notificationManager: NotificationManager

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var overlayView: ComposeView? = null
    private var overlayLifecycleOwner: OverlayLifecycleOwner? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var isForegroundStarted = false

    override fun onCreate() {
        super.onCreate()
        repository = (application as PingMonitorApplication).repository
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        createNotificationChannel()
        startForegroundWithType(buildNotification(repository.metrics.value))

        serviceScope.launch {
            repository.metrics
                .combine(repository.overlayConfig) { metrics, config -> metrics to config }
                .collect { (metrics, _) ->
                    if (isForegroundStarted) {
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(metrics))
                    }
                }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopOverlayAndService()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_MONITORING -> {
                repository.toggleMonitoring()
            }
            ACTION_START_OVERLAY, null -> {
                repository.startMonitoring()
                showOverlayIfPermitted()
            }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        clampOverlayPositionToScreen()
    }

    override fun onDestroy() {
        removeOverlayView()
        repository.setOverlayActive(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showOverlayIfPermitted() {
        if (!Settings.canDrawOverlays(this)) {
            repository.setOverlayActive(false)
            return
        }
        if (overlayView != null) {
            repository.setOverlayActive(true)
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(16)
            y = dpToPx(88)
        }

        val lifecycleOwner = OverlayLifecycleOwner().apply { onCreate() }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                val metrics by repository.metrics.collectAsState()
                val config by repository.overlayConfig.collectAsState()
                GamePingTheme {
                    OverlayHudCard(
                        metrics = metrics,
                        config = config,
                        onToggleExpand = {
                            repository.updateOverlayConfig { it.copy(isExpanded = !it.isExpanded) }
                        },
                        onToggleMonitoring = {
                            repository.toggleMonitoring()
                        },
                        onCloseOverlay = {
                            stopOverlayAndService()
                        },
                        onDragDelta = { dx, dy ->
                            updateOverlayPosition(dx, dy)
                        },
                    )
                }
            }
        }

        try {
            windowManager.addView(composeView, params)
            overlayView = composeView
            overlayLifecycleOwner = lifecycleOwner
            layoutParams = params
            repository.setOverlayActive(true)
        } catch (_: Exception) {
            lifecycleOwner.onDestroy()
            repository.setOverlayActive(false)
        }
    }

    private fun updateOverlayPosition(dx: Float, dy: Float) {
        val view = overlayView ?: return
        val params = layoutParams ?: return
        val metrics = resources.displayMetrics
        val maxX = (metrics.widthPixels - view.width).coerceAtLeast(0)
        val maxY = (metrics.heightPixels - view.height).coerceAtLeast(0)

        params.x = (params.x + dx.roundToInt()).coerceIn(0, maxX)
        params.y = (params.y + dy.roundToInt()).coerceIn(0, maxY)

        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: IllegalArgumentException) {
        }
    }

    private fun clampOverlayPositionToScreen() {
        val view = overlayView ?: return
        val params = layoutParams ?: return
        val metrics = resources.displayMetrics
        val maxX = (metrics.widthPixels - view.width).coerceAtLeast(0)
        val maxY = (metrics.heightPixels - view.height).coerceAtLeast(0)
        params.x = params.x.coerceIn(0, maxX)
        params.y = params.y.coerceIn(0, maxY)
        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: IllegalArgumentException) {
        }
    }

    private fun removeOverlayView() {
        val view = overlayView
        overlayView = null
        layoutParams = null
        if (view != null) {
            try {
                windowManager.removeView(view)
            } catch (_: IllegalArgumentException) {
            }
        }
        overlayLifecycleOwner?.onDestroy()
        overlayLifecycleOwner = null
    }

    private fun stopOverlayAndService() {
        removeOverlayView()
        repository.setOverlayActive(false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        isForegroundStarted = false
        stopSelf()
    }

    private fun startForegroundWithType(notification: Notification) {
        val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgType)
        isForegroundStarted = true
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(metrics: PingMetrics): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, PingOverlayService::class.java).apply { action = ACTION_TOGGLE_MONITORING },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, PingOverlayService::class.java).apply { action = ACTION_STOP_OVERLAY },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val pingText = if (!metrics.networkInfo.isConnected) {
            "Disconnected"
        } else if (metrics.currentPingMs != null) {
            "${metrics.currentPingMs} ms"
        } else if (metrics.isMonitoring) {
            "Measuring..."
        } else {
            "Paused"
        }

        val contentText = buildString {
            append("Ping: $pingText")
            append(" • Jitter: ${metrics.jitterMs} ms")
            append(" • ${metrics.networkInfo.connectionType.shortLabel}")
            append(" • ${metrics.stability.label}")
        }

        val toggleLabel = if (metrics.isMonitoring) {
            getString(R.string.notification_action_pause)
        } else {
            getString(R.string.notification_action_resume)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(getString(R.string.notification_title_active))
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(openAppIntent)
            .addAction(0, toggleLabel, toggleIntent)
            .addAction(0, getString(R.string.notification_action_stop), stopIntent)
            .build()
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).roundToInt()
    }

    companion object {
        private const val CHANNEL_ID = "ping_overlay_channel"
        private const val NOTIFICATION_ID = 4041

        const val ACTION_START_OVERLAY = "com.example.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"
        const val ACTION_TOGGLE_MONITORING = "com.example.action.TOGGLE_MONITORING"

        fun startOverlay(context: Context) {
            val intent = Intent(context, PingOverlayService::class.java).apply {
                action = ACTION_START_OVERLAY
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopOverlay(context: Context) {
            val intent = Intent(context, PingOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            context.startService(intent)
        }
    }
}
