package com.example

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.service.PingOverlayService
import com.example.ui.MainViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GamesAndSetupScreen
import com.example.ui.screens.OverlayStudioScreen
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.GamePingTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

private enum class AppDestination(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String,
) {
    MONITOR("Monitor", Icons.Filled.Speed, Icons.Outlined.Speed, "nav_monitor"),
    OVERLAY("Overlay", Icons.Filled.Layers, Icons.Outlined.Layers, "nav_overlay"),
    GAMES("Games", Icons.Filled.SportsEsports, Icons.Outlined.SportsEsports, "nav_games"),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GamePingTheme {
                PingMonitorApp()
            }
        }
    }
}

@Composable
private fun PingMonitorApp(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val overlayConfig by viewModel.overlayConfig.collectAsStateWithLifecycle()
    val selectedEndpoint by viewModel.selectedEndpoint.collectAsStateWithLifecycle()
    val selectedProtocol by viewModel.selectedProtocol.collectAsStateWithLifecycle()
    val selectedGameProfile by viewModel.selectedGameProfile.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()

    var currentDestination by rememberSaveable { mutableStateOf(AppDestination.MONITOR) }
    var pendingOverlayLaunch by rememberSaveable { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        viewModel.refreshPermissions()
    }

    val phoneStateLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) {
        viewModel.refreshPermissions()
    }

    val overlaySettingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) {
        viewModel.refreshPermissions()
        if (pendingOverlayLaunch && Settings.canDrawOverlays(context)) {
            pendingOverlayLaunch = false
            PingOverlayService.startOverlay(context)
        } else {
            pendingOverlayLaunch = false
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    fun requestOverlayPermissionFlow(launchAfterGrant: Boolean) {
        pendingOverlayLaunch = launchAfterGrant
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )
        try {
            overlaySettingsLauncher.launch(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(
                context,
                "Please enable Display over other apps in Android Settings",
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    fun handleToggleOverlay() {
        if (overlayConfig.isOverlayActive) {
            PingOverlayService.stopOverlay(context)
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !permissions.notificationsGranted) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (!Settings.canDrawOverlays(context)) {
                requestOverlayPermissionFlow(launchAfterGrant = true)
            } else {
                PingOverlayService.startOverlay(context)
            }
        }
    }

    if (currentDestination != AppDestination.MONITOR) {
        BackHandler {
            currentDestination = AppDestination.MONITOR
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianVoid, Color(0xFF091022), ObsidianVoid),
                ),
            ),
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = DeepSlate,
                        contentColor = TextPrimary,
                        windowInsets = WindowInsets.navigationBars,
                    ) {
                        AppDestination.entries.forEach { dest ->
                            val selected = currentDestination == dest
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentDestination = dest },
                                modifier = Modifier.testTag(dest.tag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label,
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        fontFamily = ChakraPetchFamily,
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = NeonCyan.copy(alpha = 0.14f),
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                ),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = DeepSlate,
                        contentColor = TextPrimary,
                    ) {
                        AppDestination.entries.forEach { dest ->
                            val selected = currentDestination == dest
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentDestination = dest },
                                modifier = Modifier.testTag(dest.tag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label,
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.label,
                                        fontFamily = ChakraPetchFamily,
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = NeonCyan.copy(alpha = 0.14f),
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                ),
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.MONITOR -> DashboardScreen(
                            metrics = metrics,
                            overlayConfig = overlayConfig,
                            selectedEndpoint = selectedEndpoint,
                            selectedProtocol = selectedProtocol,
                            permissions = permissions,
                            onToggleMonitoring = { viewModel.toggleMonitoring() },
                            onToggleOverlay = ::handleToggleOverlay,
                            onResetStats = { viewModel.resetSessionStats() },
                            onSelectEndpoint = { viewModel.selectEndpoint(it) },
                            onSelectProtocol = { viewModel.selectProtocol(it) },
                            onRequestOverlayPermission = {
                                requestOverlayPermissionFlow(launchAfterGrant = false)
                            },
                            onRequestNotificationPermission = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            onRequestPhonePermission = {
                                phoneStateLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                            },
                        )

                        AppDestination.OVERLAY -> OverlayStudioScreen(
                            metrics = metrics,
                            config = overlayConfig,
                            overlayPermissionGranted = permissions.overlayGranted,
                            onUpdateConfig = { transform -> viewModel.updateOverlayConfig(transform) },
                            onToggleMonitoring = { viewModel.toggleMonitoring() },
                            onToggleOverlay = ::handleToggleOverlay,
                        )

                        AppDestination.GAMES -> GamesAndSetupScreen(
                            selectedGameProfile = selectedGameProfile,
                            onSelectGameProfile = { viewModel.selectGameProfile(it) },
                            onStartOverlayAndLaunchGame = { launchIntent ->
                                if (Settings.canDrawOverlays(context)) {
                                    PingOverlayService.startOverlay(context)
                                    context.startActivity(launchIntent)
                                } else {
                                    requestOverlayPermissionFlow(launchAfterGrant = true)
                                }
                            },
                            onOpenBatterySettings = {
                                try {
                                    context.startActivity(
                                        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                                    )
                                } catch (_: ActivityNotFoundException) {
                                    context.startActivity(
                                        Intent(
                                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.parse("package:${context.packageName}"),
                                        ),
                                    )
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}
