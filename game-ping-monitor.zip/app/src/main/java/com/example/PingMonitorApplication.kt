package com.example

import android.app.Application
import com.example.network.PingMonitorRepository

class PingMonitorApplication : Application() {

    lateinit var repository: PingMonitorRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = PingMonitorRepository(this)
    }
}
