package com.example.model

import kotlin.math.abs
import kotlin.math.roundToInt

enum class ConnectionType(val label: String, val shortLabel: String) {
    WIFI("Wi-Fi", "Wi-Fi"),
    CELLULAR_5G("5G Mobile", "5G"),
    CELLULAR_4G("4G LTE", "4G LTE"),
    CELLULAR_3G("3G Mobile", "3G"),
    CELLULAR_2G("2G Mobile", "2G"),
    CELLULAR_OTHER("Mobile Data", "Mobile"),
    ETHERNET("Ethernet", "ETH"),
    VPN("VPN Tunnel", "VPN"),
    DISCONNECTED("Disconnected", "OFFLINE"),
}

enum class ConnectionStability(val label: String) {
    EXCELLENT("EXCELLENT"),
    GOOD("GOOD"),
    UNSTABLE("UNSTABLE"),
    HIGH_LATENCY("HIGH LATENCY"),
    DISCONNECTED("DISCONNECTED"),
}

enum class ProbeProtocol(val label: String, val shortLabel: String) {
    TCP_HANDSHAKE("TCP Handshake (Low Battery)", "TCP"),
    ICMP_ECHO("ICMP Echo (TCP Fallback)", "ICMP"),
}

data class TestEndpoint(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val description: String,
)

object PresetEndpoints {
    val cloudflare = TestEndpoint(
        id = "cloudflare",
        name = "Cloudflare Anycast",
        host = "1.1.1.1",
        port = 443,
        description = "Global edge anycast endpoint (1.1.1.1:443)",
    )
    val google = TestEndpoint(
        id = "google",
        name = "Google Anycast",
        host = "8.8.8.8",
        port = 443,
        description = "Google global DNS anycast (8.8.8.8:443)",
    )
    val quad9 = TestEndpoint(
        id = "quad9",
        name = "Quad9 Anycast",
        host = "9.9.9.9",
        port = 443,
        description = "Quad9 security anycast (9.9.9.9:443)",
    )
    val opendns = TestEndpoint(
        id = "opendns",
        name = "OpenDNS Anycast",
        host = "208.67.222.222",
        port = 443,
        description = "Cisco OpenDNS anycast (208.67.222.222:443)",
    )

    val all: List<TestEndpoint> = listOf(cloudflare, google, quad9, opendns)

    fun byId(id: String): TestEndpoint = all.firstOrNull { it.id == id } ?: cloudflare
}

data class GameProfile(
    val id: String,
    val name: String,
    val packageName: String?,
    val category: String,
    val recommendedTargetMs: Int,
    val preferredCompact: Boolean,
    val placementTip: String,
)

object SupportedGames {
    val profiles: List<GameProfile> = listOf(
        GameProfile(
            id = "efootball",
            name = "eFootball",
            packageName = "jp.konami.pesam",
            category = "Competitive Sports",
            recommendedTargetMs = 45,
            preferredCompact = true,
            placementTip = "Best placed top-center away from virtual stick and pass/shoot controls.",
        ),
        GameProfile(
            id = "eight_ball_pool",
            name = "8 Ball Pool",
            packageName = "com.miniclip.eightballpool",
            category = "Precision Billiards",
            recommendedTargetMs = 60,
            preferredCompact = false,
            placementTip = "Place along the top edge above the cue power bar.",
        ),
        GameProfile(
            id = "pubg_mobile",
            name = "PUBG Mobile",
            packageName = "com.tencent.ig",
            category = "Battle Royale",
            recommendedTargetMs = 45,
            preferredCompact = true,
            placementTip = "Compact HUD near top-left beside mini-map keeps fire buttons clear.",
        ),
        GameProfile(
            id = "free_fire",
            name = "Free Fire",
            packageName = "com.dts.freefireth",
            category = "Tactical Shooter",
            recommendedTargetMs = 45,
            preferredCompact = true,
            placementTip = "Top-center compact badge avoids scope and gloo-wall buttons.",
        ),
        GameProfile(
            id = "other_games",
            name = "Other Android Games",
            packageName = null,
            category = "Universal Profile",
            recommendedTargetMs = 50,
            preferredCompact = false,
            placementTip = "Works above any Android game, MOBA, racing, or cloud gaming app.",
        ),
    )

    fun byId(id: String): GameProfile = profiles.firstOrNull { it.id == id } ?: profiles.last()
}

data class NetworkStatusInfo(
    val isConnected: Boolean = false,
    val connectionType: ConnectionType = ConnectionType.DISCONNECTED,
    val transportDetail: String = "Checking active network...",
    val signalStrengthDbm: Int? = null,
    val downBandwidthKbps: Int? = null,
    val upBandwidthKbps: Int? = null,
    val isMetered: Boolean = false,
    val cellularPermissionGranted: Boolean = false,
)

data class PingSample(
    val timestampMs: Long,
    val rttMs: Int?,
    val success: Boolean,
    val endpointHost: String,
    val protocolUsed: String,
    val errorReason: String? = null,
)

data class PingMetrics(
    val isMonitoring: Boolean = false,
    val currentPingMs: Int? = null,
    val minPingMs: Int? = null,
    val maxPingMs: Int? = null,
    val avgPingMs: Int? = null,
    val jitterMs: Int = 0,
    val packetLossPercent: Float = 0f,
    val totalProbes: Int = 0,
    val failedProbes: Int = 0,
    val consecutiveFailures: Int = 0,
    val stability: ConnectionStability = ConnectionStability.DISCONNECTED,
    val networkInfo: NetworkStatusInfo = NetworkStatusInfo(),
    val recentSamples: List<PingSample> = emptyList(),
    val lastUpdatedMs: Long = 0L,
    val lastError: String? = null,
    val activeEndpointName: String = PresetEndpoints.cloudflare.name,
    val activeEndpointHost: String = PresetEndpoints.cloudflare.host,
    val activeProtocolLabel: String = ProbeProtocol.TCP_HANDSHAKE.shortLabel,
)

data class OverlayConfig(
    val isOverlayActive: Boolean = false,
    val isExpanded: Boolean = true,
    val sizeScale: Float = 1.0f,
    val opacity: Float = 0.88f,
    val showJitter: Boolean = true,
    val showPacketLoss: Boolean = true,
    val showNetworkType: Boolean = true,
    val lockPosition: Boolean = false,
)

object PingMetricsCalculator {

    private const val RECENT_WINDOW_SIZE = 30
    private const val JITTER_WINDOW_SIZE = 20

    fun compute(
        isMonitoring: Boolean,
        allSamples: List<PingSample>,
        networkInfo: NetworkStatusInfo,
        activeEndpoint: TestEndpoint,
        activeProtocol: ProbeProtocol,
    ): PingMetrics {
        val recent60 = if (allSamples.size > 60) allSamples.takeLast(60) else allSamples
        val recentLossWindow = if (allSamples.size > RECENT_WINDOW_SIZE) {
            allSamples.takeLast(RECENT_WINDOW_SIZE)
        } else {
            allSamples
        }

        val successfulSamples = allSamples.mapNotNull { it.rttMs }
        val latestSample = allSamples.lastOrNull()
        val currentPing = if (networkInfo.isConnected) {
            latestSample?.takeIf { it.success }?.rttMs
        } else {
            null
        }

        val minPing = successfulSamples.minOrNull()
        val maxPing = successfulSamples.maxOrNull()
        val avgPing = if (successfulSamples.isNotEmpty()) {
            successfulSamples.average().roundToInt()
        } else {
            null
        }

        val recentSuccesses = recent60.takeLast(JITTER_WINDOW_SIZE).mapNotNull { it.rttMs }
        val jitter = calculateJitter(recentSuccesses)

        val totalCount = allSamples.size
        val failedCount = allSamples.count { !it.success }
        val windowLossPercent = if (recentLossWindow.isNotEmpty()) {
            val windowFailed = recentLossWindow.count { !it.success }
            (windowFailed.toFloat() / recentLossWindow.size.toFloat()) * 100f
        } else {
            0f
        }

        var consecutiveFailures = 0
        for (i in allSamples.indices.reversed()) {
            if (!allSamples[i].success) consecutiveFailures++ else break
        }

        val stability = classifyStability(
            networkConnected = networkInfo.isConnected,
            currentPingMs = currentPing,
            avgPingMs = avgPing,
            jitterMs = jitter,
            packetLossPercent = windowLossPercent,
            consecutiveFailures = consecutiveFailures,
            totalProbes = totalCount,
        )

        return PingMetrics(
            isMonitoring = isMonitoring,
            currentPingMs = currentPing,
            minPingMs = minPing,
            maxPingMs = maxPing,
            avgPingMs = avgPing,
            jitterMs = jitter,
            packetLossPercent = windowLossPercent,
            totalProbes = totalCount,
            failedProbes = failedCount,
            consecutiveFailures = consecutiveFailures,
            stability = stability,
            networkInfo = networkInfo,
            recentSamples = recent60,
            lastUpdatedMs = latestSample?.timestampMs ?: 0L,
            lastError = latestSample?.errorReason,
            activeEndpointName = activeEndpoint.name,
            activeEndpointHost = activeEndpoint.host,
            activeProtocolLabel = latestSample?.protocolUsed ?: activeProtocol.shortLabel,
        )
    }

    fun calculateJitter(rtts: List<Int>): Int {
        if (rtts.size < 2) return 0
        var diffSum = 0L
        for (i in 1 until rtts.size) {
            diffSum += abs(rtts[i] - rtts[i - 1])
        }
        return (diffSum.toDouble() / (rtts.size - 1)).roundToInt()
    }

    fun classifyStability(
        networkConnected: Boolean,
        currentPingMs: Int?,
        avgPingMs: Int?,
        jitterMs: Int,
        packetLossPercent: Float,
        consecutiveFailures: Int,
        totalProbes: Int,
    ): ConnectionStability {
        if (!networkConnected) return ConnectionStability.DISCONNECTED
        if (totalProbes > 0 && consecutiveFailures >= 3) return ConnectionStability.DISCONNECTED

        val referencePing = currentPingMs ?: avgPingMs ?: return ConnectionStability.GOOD

        if (packetLossPercent >= 15f || referencePing >= 150) {
            return ConnectionStability.HIGH_LATENCY
        }
        if (packetLossPercent >= 5f || jitterMs >= 25 || referencePing >= 90) {
            return ConnectionStability.UNSTABLE
        }
        if (referencePing < 45 && jitterMs < 12 && packetLossPercent < 1f) {
            return ConnectionStability.EXCELLENT
        }
        return ConnectionStability.GOOD
    }
}
