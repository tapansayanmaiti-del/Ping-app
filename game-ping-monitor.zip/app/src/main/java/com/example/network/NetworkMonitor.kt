package com.example.network

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.model.ConnectionType
import com.example.model.NetworkStatusInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executor

class NetworkMonitor(context: Context) {

    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val telephonyManager =
        appContext.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

    private val _networkStatus = MutableStateFlow(readCurrentNetworkStatus())
    val networkStatus: StateFlow<NetworkStatusInfo> = _networkStatus.asStateFlow()

    @Volatile
    private var overrideNetworkType: Int = TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NONE

    private var registered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            refreshNetworkStatus()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities,
        ) {
            refreshNetworkStatus(networkCapabilities)
        }

        override fun onLost(network: Network) {
            refreshNetworkStatus()
        }

        override fun onUnavailable() {
            refreshNetworkStatus()
        }
    }

    private var telephonyCallback: Any? = null
    @Suppress("DEPRECATION")
    private var legacyPhoneStateListener: PhoneStateListener? = null

    fun start() {
        if (registered) {
            refreshNetworkStatus()
            return
        }
        registered = true
        try {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        } catch (_: SecurityException) {
            // Handled gracefully
        } catch (_: RuntimeException) {
            // Too many callbacks or system error
        }
        registerTelephonyUpdatesIfPermitted()
        refreshNetworkStatus()
    }

    fun stop() {
        if (!registered) return
        registered = false
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (_: IllegalArgumentException) {
            // Already unregistered
        }
        unregisterTelephonyUpdates()
    }

    fun refreshNetworkStatus(overrideCapabilities: NetworkCapabilities? = null) {
        _networkStatus.value = readCurrentNetworkStatus(overrideCapabilities)
    }

    private fun registerTelephonyUpdatesIfPermitted() {
        val tm = telephonyManager ?: return
        if (!hasPhoneStatePermission()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val callback = object : TelephonyCallback(), TelephonyCallback.DisplayInfoListener {
                override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
                    overrideNetworkType = telephonyDisplayInfo.overrideNetworkType
                    refreshNetworkStatus()
                }
            }
            telephonyCallback = callback
            val executor: Executor = ContextCompat.getMainExecutor(appContext)
            try {
                tm.registerTelephonyCallback(executor, callback)
            } catch (_: SecurityException) {
                telephonyCallback = null
            }
        } else {
            @Suppress("DEPRECATION")
            val listener = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onDataConnectionStateChanged(state: Int, networkType: Int) {
                    refreshNetworkStatus()
                }
            }
            legacyPhoneStateListener = listener
            try {
                @Suppress("DEPRECATION")
                tm.listen(listener, PhoneStateListener.LISTEN_DATA_CONNECTION_STATE)
            } catch (_: SecurityException) {
                legacyPhoneStateListener = null
            }
        }
    }

    private fun unregisterTelephonyUpdates() {
        val tm = telephonyManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val cb = telephonyCallback as? TelephonyCallback
            if (cb != null) {
                try {
                    tm.unregisterTelephonyCallback(cb)
                } catch (_: Exception) {
                }
            }
            telephonyCallback = null
        } else {
            @Suppress("DEPRECATION")
            val listener = legacyPhoneStateListener
            if (listener != null) {
                try {
                    @Suppress("DEPRECATION")
                    tm.listen(listener, PhoneStateListener.LISTEN_NONE)
                } catch (_: Exception) {
                }
            }
            legacyPhoneStateListener = null
        }
    }

    private fun hasPhoneStatePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.READ_PHONE_STATE,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun readCurrentNetworkStatus(overrideCaps: NetworkCapabilities? = null): NetworkStatusInfo {
        val phonePerm = hasPhoneStatePermission()
        val activeNetwork = connectivityManager.activeNetwork
        val caps = overrideCaps ?: activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }

        if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
            return NetworkStatusInfo(
                isConnected = false,
                connectionType = ConnectionType.DISCONNECTED,
                transportDetail = "No active internet interface",
                cellularPermissionGranted = phonePerm,
            )
        }

        val isValidated = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } else {
            true
        }

        val isMetered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
        val signalDbm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rawSignal = caps.signalStrength
            if (rawSignal != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) rawSignal else null
        } else {
            null
        }
        val downKbps = caps.linkDownstreamBandwidthKbps.takeIf { it > 0 }
        val upKbps = caps.linkUpstreamBandwidthKbps.takeIf { it > 0 }

        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnectionType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> detectCellularGeneration(phonePerm)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> ConnectionType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> ConnectionType.VPN
            else -> ConnectionType.CELLULAR_OTHER
        }

        val detail = buildString {
            append(type.label)
            if (!isValidated) append(" (Validating)")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) && type != ConnectionType.VPN) {
                append(" + VPN")
            }
        }

        return NetworkStatusInfo(
            isConnected = true,
            connectionType = type,
            transportDetail = detail,
            signalStrengthDbm = signalDbm,
            downBandwidthKbps = downKbps,
            upBandwidthKbps = upKbps,
            isMetered = isMetered,
            cellularPermissionGranted = phonePerm,
        )
    }

    private fun detectCellularGeneration(hasPermission: Boolean): ConnectionType {
        if (!hasPermission) return ConnectionType.CELLULAR_OTHER
        val tm = telephonyManager ?: return ConnectionType.CELLULAR_OTHER

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA ||
                overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED
            ) {
                return ConnectionType.CELLULAR_5G
            }
        }

        val dataType = try {
            tm.dataNetworkType
        } catch (_: SecurityException) {
            return ConnectionType.CELLULAR_OTHER
        }

        return mapNetworkType(dataType)
    }

    companion object {
        fun mapNetworkType(networkType: Int): ConnectionType {
            return when (networkType) {
                TelephonyManager.NETWORK_TYPE_NR -> ConnectionType.CELLULAR_5G
                TelephonyManager.NETWORK_TYPE_LTE -> ConnectionType.CELLULAR_4G
                TelephonyManager.NETWORK_TYPE_UMTS,
                TelephonyManager.NETWORK_TYPE_EVDO_0,
                TelephonyManager.NETWORK_TYPE_EVDO_A,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_HSUPA,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_EVDO_B,
                TelephonyManager.NETWORK_TYPE_EHRPD,
                TelephonyManager.NETWORK_TYPE_HSPAP,
                TelephonyManager.NETWORK_TYPE_TD_SCDMA -> ConnectionType.CELLULAR_3G
                TelephonyManager.NETWORK_TYPE_GPRS,
                TelephonyManager.NETWORK_TYPE_EDGE,
                TelephonyManager.NETWORK_TYPE_CDMA,
                TelephonyManager.NETWORK_TYPE_1xRTT,
                TelephonyManager.NETWORK_TYPE_IDEN,
                TelephonyManager.NETWORK_TYPE_GSM -> ConnectionType.CELLULAR_2G
                else -> ConnectionType.CELLULAR_OTHER
            }
        }
    }
}
