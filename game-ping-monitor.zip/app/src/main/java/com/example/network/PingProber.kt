package com.example.network

import android.os.SystemClock
import com.example.model.PingSample
import com.example.model.ProbeProtocol
import com.example.model.TestEndpoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class PingProber {

    suspend fun measure(
        endpoint: TestEndpoint,
        protocol: ProbeProtocol,
        timeoutMs: Int = 900,
    ): PingSample = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        when (protocol) {
            ProbeProtocol.TCP_HANDSHAKE -> measureTcpConnect(endpoint, timeoutMs, timestamp)
            ProbeProtocol.ICMP_ECHO -> {
                val icmpResult = measureIcmpCommand(endpoint.host, timeoutMs, timestamp)
                if (icmpResult.success) {
                    icmpResult
                } else {
                    // Fallback to TCP Handshake when Android SELinux blocks /system/bin/ping
                    measureTcpConnect(endpoint, timeoutMs, timestamp, fallbackTag = "TCP (ICMP N/A)")
                }
            }
        }
    }

    private fun measureTcpConnect(
        endpoint: TestEndpoint,
        timeoutMs: Int,
        timestampMs: Long,
        fallbackTag: String = "TCP",
    ): PingSample {
        var socket: Socket? = null
        return try {
            val address = InetAddress.getByName(endpoint.host)
            socket = Socket()
            socket.tcpNoDelay = true
            val startNanos = SystemClock.elapsedRealtimeNanos()
            socket.connect(InetSocketAddress(address, endpoint.port), timeoutMs)
            val elapsedNanos = SystemClock.elapsedRealtimeNanos() - startNanos
            val rttMs = (elapsedNanos / 1_000_000.0).roundToInt().coerceAtLeast(1)
            PingSample(
                timestampMs = timestampMs,
                rttMs = rttMs,
                success = true,
                endpointHost = endpoint.host,
                protocolUsed = fallbackTag,
            )
        } catch (e: Exception) {
            PingSample(
                timestampMs = timestampMs,
                rttMs = null,
                success = false,
                endpointHost = endpoint.host,
                protocolUsed = fallbackTag,
                errorReason = e.message ?: "Connection timeout",
            )
        } finally {
            try {
                socket?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun measureIcmpCommand(
        host: String,
        timeoutMs: Int,
        timestampMs: Long,
    ): PingSample {
        var process: Process? = null
        return try {
            val timeoutSec = ((timeoutMs + 999) / 1000).coerceAtLeast(1)
            process = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", timeoutSec.toString(), host)
                .redirectErrorStream(true)
                .start()
            val finished = process.waitFor(timeoutMs.toLong() + 150L, TimeUnit.MILLISECONDS)
            if (!finished) {
                process.destroyForcibly()
                return PingSample(
                    timestampMs = timestampMs,
                    rttMs = null,
                    success = false,
                    endpointHost = host,
                    protocolUsed = "ICMP",
                    errorReason = "ICMP timeout",
                )
            }
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val rtt = parseIcmpLatencyMs(output)
            if (process.exitValue() == 0 && rtt != null) {
                PingSample(
                    timestampMs = timestampMs,
                    rttMs = rtt,
                    success = true,
                    endpointHost = host,
                    protocolUsed = "ICMP",
                )
            } else {
                PingSample(
                    timestampMs = timestampMs,
                    rttMs = null,
                    success = false,
                    endpointHost = host,
                    protocolUsed = "ICMP",
                    errorReason = "ICMP unreachable",
                )
            }
        } catch (e: Exception) {
            PingSample(
                timestampMs = timestampMs,
                rttMs = null,
                success = false,
                endpointHost = host,
                protocolUsed = "ICMP",
                errorReason = e.message ?: "ICMP error",
            )
        } finally {
            process?.destroy()
        }
    }

    companion object {
        private val TIME_REGEX = Regex("""time[=<]\s*([0-9]+(?:\.[0-9]+)?)\s*ms""", RegexOption.IGNORE_CASE)

        fun parseIcmpLatencyMs(pingOutput: String): Int? {
            val match = TIME_REGEX.find(pingOutput) ?: return null
            val rawValue = match.groupValues.getOrNull(1)?.toDoubleOrNull() ?: return null
            return rawValue.roundToInt().coerceAtLeast(1)
        }
    }
}
