package com.example.network

import android.content.Context
import android.os.SystemClock
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.GameProfile
import com.example.model.OverlayConfig
import com.example.model.PingMetrics
import com.example.model.PingMetricsCalculator
import com.example.model.PingSample
import com.example.model.PresetEndpoints
import com.example.model.ProbeProtocol
import com.example.model.SupportedGames
import com.example.model.TestEndpoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private val Context.pingMonitorDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "ping_monitor_prefs",
)

class PingMonitorRepository(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val networkMonitor = NetworkMonitor(appContext)
    private val pingProber = PingProber()

    private val _selectedEndpoint = MutableStateFlow(PresetEndpoints.cloudflare)
    val selectedEndpoint: StateFlow<TestEndpoint> = _selectedEndpoint.asStateFlow()

    private val _selectedProtocol = MutableStateFlow(ProbeProtocol.TCP_HANDSHAKE)
    val selectedProtocol: StateFlow<ProbeProtocol> = _selectedProtocol.asStateFlow()

    private val _selectedGameProfile = MutableStateFlow(SupportedGames.profiles.first())
    val selectedGameProfile: StateFlow<GameProfile> = _selectedGameProfile.asStateFlow()

    private val _overlayConfig = MutableStateFlow(OverlayConfig())
    val overlayConfig: StateFlow<OverlayConfig> = _overlayConfig.asStateFlow()

    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring: StateFlow<Boolean> = _isMonitoring.asStateFlow()

    private val sampleLock = Any()
    private val sessionSamples = ArrayList<PingSample>(300)

    private val _metrics = MutableStateFlow(
        PingMetricsCalculator.compute(
            isMonitoring = false,
            allSamples = emptyList(),
            networkInfo = networkMonitor.networkStatus.value,
            activeEndpoint = _selectedEndpoint.value,
            activeProtocol = _selectedProtocol.value,
        ),
    )
    val metrics: StateFlow<PingMetrics> = _metrics.asStateFlow()

    private var probeJob: Job? = null

    init {
        networkMonitor.start()
        scope.launch {
            loadSavedPreferences()
        }
        scope.launch {
            networkMonitor.networkStatus.collect {
                publishComputedMetrics()
            }
        }
    }

    private suspend fun loadSavedPreferences() {
        val prefs = appContext.pingMonitorDataStore.data.first()
        val endpointId = prefs[KEY_ENDPOINT_ID] ?: PresetEndpoints.cloudflare.id
        _selectedEndpoint.value = PresetEndpoints.byId(endpointId)

        val protocolName = prefs[KEY_PROTOCOL] ?: ProbeProtocol.TCP_HANDSHAKE.name
        _selectedProtocol.value = runCatching { ProbeProtocol.valueOf(protocolName) }
            .getOrDefault(ProbeProtocol.TCP_HANDSHAKE)

        val gameId = prefs[KEY_GAME_PROFILE_ID] ?: SupportedGames.profiles.first().id
        _selectedGameProfile.value = SupportedGames.byId(gameId)

        _overlayConfig.update { current ->
            current.copy(
                sizeScale = (prefs[KEY_OVERLAY_SIZE] ?: 1.0f).coerceIn(0.75f, 1.35f),
                opacity = (prefs[KEY_OVERLAY_OPACITY] ?: 0.88f).coerceIn(0.35f, 1.0f),
                isExpanded = prefs[KEY_OVERLAY_EXPANDED] ?: true,
                showJitter = prefs[KEY_SHOW_JITTER] ?: true,
                showPacketLoss = prefs[KEY_SHOW_LOSS] ?: true,
                showNetworkType = prefs[KEY_SHOW_NETWORK] ?: true,
                lockPosition = prefs[KEY_LOCK_POSITION] ?: false,
            )
        }
        publishComputedMetrics()
    }

    fun startMonitoring() {
        networkMonitor.refreshNetworkStatus()
        if (_isMonitoring.value && probeJob?.isActive == true) return
        _isMonitoring.value = true
        publishComputedMetrics()

        probeJob?.cancel()
        probeJob = scope.launch {
            while (isActive && _isMonitoring.value) {
                val loopStart = SystemClock.elapsedRealtime()
                val currentNet = networkMonitor.networkStatus.value
                if (currentNet.isConnected) {
                    val sample = pingProber.measure(
                        endpoint = _selectedEndpoint.value,
                        protocol = _selectedProtocol.value,
                        timeoutMs = 850,
                    )
                    if (_isMonitoring.value) {
                        appendSample(sample)
                    }
                } else {
                    // Battery-friendly idle skip when disconnected: do not open sockets offline
                    publishComputedMetrics()
                }
                val elapsed = SystemClock.elapsedRealtime() - loopStart
                val remaining = (1000L - elapsed).coerceAtLeast(100L)
                delay(remaining)
            }
        }
    }

    fun pauseMonitoring() {
        _isMonitoring.value = false
        probeJob?.cancel()
        probeJob = null
        publishComputedMetrics()
    }

    fun toggleMonitoring() {
        if (_isMonitoring.value) pauseMonitoring() else startMonitoring()
    }

    fun resetSessionStats() {
        synchronized(sampleLock) {
            sessionSamples.clear()
        }
        publishComputedMetrics()
    }

    fun selectEndpoint(endpoint: TestEndpoint) {
        _selectedEndpoint.value = endpoint
        synchronized(sampleLock) {
            sessionSamples.clear()
        }
        publishComputedMetrics()
        scope.launch {
            appContext.pingMonitorDataStore.edit { it[KEY_ENDPOINT_ID] = endpoint.id }
        }
    }

    fun selectProtocol(protocol: ProbeProtocol) {
        _selectedProtocol.value = protocol
        publishComputedMetrics()
        scope.launch {
            appContext.pingMonitorDataStore.edit { it[KEY_PROTOCOL] = protocol.name }
        }
    }

    fun selectGameProfile(profile: GameProfile) {
        _selectedGameProfile.value = profile
        updateOverlayConfig { it.copy(isExpanded = !profile.preferredCompact) }
    }

    fun setOverlayActive(active: Boolean) {
        _overlayConfig.update { it.copy(isOverlayActive = active) }
    }

    fun updateOverlayConfig(transform: (OverlayConfig) -> OverlayConfig) {
        val updated = transform(_overlayConfig.value)
        _overlayConfig.value = updated
        scope.launch {
            appContext.pingMonitorDataStore.edit { prefs ->
                prefs[KEY_OVERLAY_SIZE] = updated.sizeScale
                prefs[KEY_OVERLAY_OPACITY] = updated.opacity
                prefs[KEY_OVERLAY_EXPANDED] = updated.isExpanded
                prefs[KEY_SHOW_JITTER] = updated.showJitter
                prefs[KEY_SHOW_LOSS] = updated.showPacketLoss
                prefs[KEY_SHOW_NETWORK] = updated.showNetworkType
                prefs[KEY_LOCK_POSITION] = updated.lockPosition
            }
        }
    }

    fun refreshNetwork() {
        networkMonitor.refreshNetworkStatus()
    }

    private fun appendSample(sample: PingSample) {
        synchronized(sampleLock) {
            if (sessionSamples.size >= MAX_SESSION_SAMPLES) {
                sessionSamples.removeAt(0)
            }
            sessionSamples.add(sample)
        }
        publishComputedMetrics()
    }

    private fun publishComputedMetrics() {
        val snapshot = synchronized(sampleLock) { sessionSamples.toList() }
        _metrics.value = PingMetricsCalculator.compute(
            isMonitoring = _isMonitoring.value,
            allSamples = snapshot,
            networkInfo = networkMonitor.networkStatus.value,
            activeEndpoint = _selectedEndpoint.value,
            activeProtocol = _selectedProtocol.value,
        )
    }

    companion object {
        private const val MAX_SESSION_SAMPLES = 600
        private val KEY_ENDPOINT_ID = stringPreferencesKey("endpoint_id")
        private val KEY_PROTOCOL = stringPreferencesKey("probe_protocol")
        private val KEY_GAME_PROFILE_ID = stringPreferencesKey("game_profile_id")
        private val KEY_OVERLAY_SIZE = floatPreferencesKey("overlay_size")
        private val KEY_OVERLAY_OPACITY = floatPreferencesKey("overlay_opacity")
        private val KEY_OVERLAY_EXPANDED = booleanPreferencesKey("overlay_expanded")
        private val KEY_SHOW_JITTER = booleanPreferencesKey("show_jitter")
        private val KEY_SHOW_LOSS = booleanPreferencesKey("show_loss")
        private val KEY_SHOW_NETWORK = booleanPreferencesKey("show_network")
        private val KEY_LOCK_POSITION = booleanPreferencesKey("lock_position")
    }
}
