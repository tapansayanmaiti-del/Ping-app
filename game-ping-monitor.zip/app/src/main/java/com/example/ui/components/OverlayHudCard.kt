package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.OverlayConfig
import com.example.model.PingMetrics
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.stabilityColor
import kotlin.math.roundToInt

@Composable
fun OverlayHudCard(
    metrics: PingMetrics,
    config: OverlayConfig,
    onToggleExpand: () -> Unit,
    onToggleMonitoring: () -> Unit,
    onCloseOverlay: () -> Unit,
    modifier: Modifier = Modifier,
    onDragDelta: ((dx: Float, dy: Float) -> Unit)? = null,
) {
    val statusColor by animateColorAsState(
        targetValue = stabilityColor(metrics.stability),
        label = "overlay_status_color",
    )

    val scale = config.sizeScale.coerceIn(0.75f, 1.35f)
    val bgAlpha = config.opacity.coerceIn(0.35f, 1.0f)

    val dragModifier = if (onDragDelta != null && !config.lockPosition) {
        Modifier.pointerInput(config.lockPosition) {
            detectDragGestures { change, dragAmount ->
                change.consume()
                onDragDelta(dragAmount.x, dragAmount.y)
            }
        }
    } else {
        Modifier
    }

    val containerShape = RoundedCornerShape((14 * scale).dp)
    val bgBrush = Brush.linearGradient(
        colors = listOf(
            DeepSlate.copy(alpha = bgAlpha),
            Color(0xFF0C152B).copy(alpha = bgAlpha),
        ),
    )

    val pingDisplay = when {
        !metrics.networkInfo.isConnected -> "--"
        metrics.currentPingMs != null -> "${metrics.currentPingMs} ms"
        metrics.isMonitoring -> "..."
        else -> "PAUSED"
    }

    if (!config.isExpanded) {
        // Minimized compact pill
        Row(
            modifier = modifier
                .then(dragModifier)
                .clip(RoundedCornerShape(50))
                .background(bgBrush)
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.7f), ElectricViolet.copy(alpha = 0.7f))),
                    shape = RoundedCornerShape(50),
                )
                .padding(horizontal = (10 * scale).dp, vertical = (6 * scale).dp)
                .testTag("overlay_minimized_pill"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((7 * scale).dp),
        ) {
            Box(
                modifier = Modifier
                    .size((8 * scale).dp)
                    .clip(CircleShape)
                    .background(statusColor),
            )
            Text(
                text = pingDisplay,
                color = statusColor,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = (13 * scale).sp,
            )
            if (config.showNetworkType) {
                Text(
                    text = metrics.networkInfo.connectionType.shortLabel,
                    color = NeonCyan,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = (11 * scale).sp,
                )
            }
            HudMiniAction(
                icon = if (metrics.isMonitoring) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = stringResource(R.string.cd_overlay_toggle_monitoring),
                tint = TextPrimary,
                sizeDp = (16 * scale).dp,
                onClick = onToggleMonitoring,
                tag = "overlay_mini_toggle_btn",
            )
            HudMiniAction(
                icon = Icons.Filled.ExpandMore,
                contentDescription = stringResource(R.string.cd_overlay_expand),
                tint = NeonCyan,
                sizeDp = (16 * scale).dp,
                onClick = onToggleExpand,
                tag = "overlay_expand_btn",
            )
            HudMiniAction(
                icon = Icons.Filled.Close,
                contentDescription = stringResource(R.string.cd_overlay_close),
                tint = TextSecondary,
                sizeDp = (15 * scale).dp,
                onClick = onCloseOverlay,
                tag = "overlay_mini_close_btn",
            )
        }
    } else {
        // Expanded Gaming HUD
        Column(
            modifier = modifier
                .then(dragModifier)
                .widthIn(min = (186 * scale).dp, max = (240 * scale).dp)
                .clip(containerShape)
                .background(bgBrush)
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            NeonCyan.copy(alpha = 0.75f),
                            ElectricViolet.copy(alpha = 0.75f),
                        ),
                    ),
                    shape = containerShape,
                )
                .padding(horizontal = (11 * scale).dp, vertical = (9 * scale).dp)
                .testTag("overlay_expanded_hud"),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.widthIn(min = (164 * scale).dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy((4 * scale).dp),
                ) {
                    Icon(
                        imageVector = if (config.lockPosition) Icons.Filled.Lock else Icons.Filled.DragIndicator,
                        contentDescription = stringResource(R.string.cd_overlay_drag),
                        tint = NeonCyan.copy(alpha = 0.85f),
                        modifier = Modifier.size((14 * scale).dp),
                    )
                    Text(
                        text = "PING HUD",
                        color = NeonCyan,
                        fontFamily = ChakraPetchFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = (10 * scale).sp,
                        letterSpacing = 1.sp,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy((6 * scale).dp)) {
                    HudMiniAction(
                        icon = if (metrics.isMonitoring) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = stringResource(R.string.cd_overlay_toggle_monitoring),
                        tint = if (metrics.isMonitoring) NeonCyan else TextPrimary,
                        sizeDp = (16 * scale).dp,
                        onClick = onToggleMonitoring,
                        tag = "overlay_toggle_monitoring_btn",
                    )
                    HudMiniAction(
                        icon = Icons.Filled.ExpandLess,
                        contentDescription = stringResource(R.string.cd_overlay_minimize),
                        tint = TextSecondary,
                        sizeDp = (16 * scale).dp,
                        onClick = onToggleExpand,
                        tag = "overlay_minimize_btn",
                    )
                    HudMiniAction(
                        icon = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.cd_overlay_close),
                        tint = Color(0xFFFF6B81),
                        sizeDp = (16 * scale).dp,
                        onClick = onCloseOverlay,
                        tag = "overlay_close_btn",
                    )
                }
            }

            Spacer(modifier = Modifier.height((5 * scale).dp))

            HudMetricRow(
                label = "PING:",
                value = pingDisplay,
                valueColor = statusColor,
                scale = scale,
                boldValue = true,
            )
            if (config.showJitter) {
                HudMetricRow(
                    label = "JITTER:",
                    value = if (metrics.totalProbes > 1) "${metrics.jitterMs} ms" else "--",
                    valueColor = TextPrimary,
                    scale = scale,
                )
            }
            if (config.showPacketLoss) {
                HudMetricRow(
                    label = "PACKET LOSS:",
                    value = "${metrics.packetLossPercent.roundToInt()}%",
                    valueColor = if (metrics.packetLossPercent >= 5f) Color(0xFFFF6B81) else TextPrimary,
                    scale = scale,
                )
            }
            if (config.showNetworkType) {
                HudMetricRow(
                    label = "NETWORK:",
                    value = metrics.networkInfo.connectionType.shortLabel,
                    valueColor = NeonCyan,
                    scale = scale,
                )
            }
            HudMetricRow(
                label = "STATUS:",
                value = metrics.stability.label,
                valueColor = statusColor,
                scale = scale,
                boldValue = true,
            )
        }
    }
}

@Composable
private fun HudMetricRow(
    label: String,
    value: String,
    valueColor: Color,
    scale: Float,
    boldValue: Boolean = false,
) {
    Row(
        modifier = Modifier.padding(vertical = (1.5f * scale).dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontFamily = ChakraPetchFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (10.5f * scale).sp,
        )
        Spacer(modifier = Modifier.width((5 * scale).dp))
        Text(
            text = value,
            color = valueColor,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = if (boldValue) FontWeight.Bold else FontWeight.Medium,
            fontSize = (11.5f * scale).sp,
        )
    }
}

@Composable
private fun HudMiniAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    tint: Color,
    sizeDp: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    tag: String,
) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(4.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(sizeDp),
        )
    }
}
