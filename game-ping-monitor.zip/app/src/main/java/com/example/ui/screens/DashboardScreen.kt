package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SignalWifi4Bar
import androidx.compose.material.icons.filled.SignalWifiOff
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ConnectionType
import com.example.model.OverlayConfig
import com.example.model.PingMetrics
import com.example.model.PresetEndpoints
import com.example.model.ProbeProtocol
import com.example.model.TestEndpoint
import com.example.ui.PermissionStatus
import com.example.ui.components.LatencyChart
import com.example.ui.components.PingGauge
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.GlassPanel
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCrimson
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(
    metrics: PingMetrics,
    overlayConfig: OverlayConfig,
    selectedEndpoint: TestEndpoint,
    selectedProtocol: ProbeProtocol,
    permissions: PermissionStatus,
    onToggleMonitoring: () -> Unit,
    onToggleOverlay: () -> Unit,
    onResetStats: () -> Unit,
    onSelectEndpoint: (TestEndpoint) -> Unit,
    onSelectProtocol: (ProbeProtocol) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestPhonePermission: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Top Tactical Header + Network Pill
            DashboardHeader(metrics = metrics)

            // Scope Disclosure Pill (Internet Endpoint vs Game Server)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(GlassPanel.copy(alpha = 0.7f))
                    .border(1.dp, NeonCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    text = "Measures active device internet latency to public test servers — not internal game server ping.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                )
            }

            // Hero Gauge Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(ElevatedCard, DeepSlate),
                        ),
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            listOf(NeonCyan.copy(alpha = 0.35f), ElectricViolet.copy(alpha = 0.35f)),
                        ),
                        shape = RoundedCornerShape(22.dp),
                    )
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                PingGauge(metrics = metrics)

                if (!metrics.networkInfo.isConnected) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Network disconnected — monitoring pauses probes until connection returns",
                        color = SignalAmber,
                        fontSize = 12.sp,
                    )
                } else if (metrics.lastError != null && metrics.consecutiveFailures > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Probe timeout (${metrics.consecutiveFailures} consecutive drops)",
                        color = SignalCrimson,
                        fontSize = 12.sp,
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Primary Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onToggleMonitoring,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("monitor_toggle_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (metrics.isMonitoring) Color(0xFF1F2B47) else NeonCyan,
                            contentColor = if (metrics.isMonitoring) TextPrimary else ObsidianVoid,
                        ),
                    ) {
                        Icon(
                            imageVector = if (metrics.isMonitoring) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (metrics.isMonitoring) "Pause Ping" else "Start Ping",
                            fontFamily = ChakraPetchFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    }

                    Button(
                        onClick = onToggleOverlay,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("overlay_toggle_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (overlayConfig.isOverlayActive) SignalCrimson else ElectricViolet,
                            contentColor = TextPrimary,
                        ),
                    ) {
                        Icon(
                            imageVector = if (overlayConfig.isOverlayActive) Icons.Filled.Close else Icons.Filled.Layers,
                            contentDescription = null,
                            modifier = Modifier.size(19.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (overlayConfig.isOverlayActive) "Close HUD" else "Launch HUD",
                            fontFamily = ChakraPetchFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    }
                }
            }

            // Permissions Checklist Card (shown when any system permission is missing)
            val missingAnyPermission =
                !permissions.overlayGranted || !permissions.notificationsGranted || !permissions.phoneStateGranted
            AnimatedVisibility(visible = missingAnyPermission) {
                PermissionReadinessCard(
                    permissions = permissions,
                    onRequestOverlay = onRequestOverlayPermission,
                    onRequestNotifications = onRequestNotificationPermission,
                    onRequestPhoneState = onRequestPhonePermission,
                )
            }

            // 4-Card Telemetry Grid (Min / Max / Avg / Jitter + Packet Loss)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MetricStatCard(
                    title = "MIN PING",
                    value = metrics.minPingMs?.let { "$it ms" } ?: "--",
                    subtitle = "Lowest RTT",
                    accentColor = SignalEmerald,
                    modifier = Modifier.weight(1f),
                )
                MetricStatCard(
                    title = "MAX PING",
                    value = metrics.maxPingMs?.let { "$it ms" } ?: "--",
                    subtitle = "Peak Spike",
                    accentColor = SignalAmber,
                    modifier = Modifier.weight(1f),
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MetricStatCard(
                    title = "AVG PING",
                    value = metrics.avgPingMs?.let { "$it ms" } ?: "--",
                    subtitle = "${metrics.totalProbes} probes",
                    accentColor = NeonCyan,
                    modifier = Modifier.weight(1f),
                )
                MetricStatCard(
                    title = "JITTER & LOSS",
                    value = "${metrics.jitterMs} ms",
                    subtitle = "Loss: ${metrics.packetLossPercent.roundToInt()}% (${metrics.failedProbes} lost)",
                    accentColor = if (metrics.packetLossPercent >= 5f || metrics.jitterMs >= 25) {
                        SignalCrimson
                    } else {
                        ElectricViolet
                    },
                    modifier = Modifier.weight(1f),
                )
            }

            // Real-time 60s Latency Chart + Reset button
            LatencyChart(samples = metrics.recentSamples)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "TEST SERVER ENDPOINT",
                    color = TextSecondary,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    letterSpacing = 0.8.sp,
                )
                TextButton(
                    onClick = onResetStats,
                    modifier = Modifier.testTag("reset_stats_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Reset Stats",
                        color = NeonCyan,
                        fontFamily = ChakraPetchFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                    )
                }
            }

            // Endpoint Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                PresetEndpoints.all.forEach { endpoint ->
                    val selected = endpoint.id == selectedEndpoint.id
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectEndpoint(endpoint) },
                        label = {
                            Text(
                                text = "${endpoint.name} (${endpoint.host})",
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 11.sp,
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Dns,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan.copy(alpha = 0.16f),
                            selectedLabelColor = NeonCyan,
                            selectedLeadingIconColor = NeonCyan,
                            containerColor = ElevatedCard,
                            labelColor = TextSecondary,
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = SubtleBorder,
                            selectedBorderColor = NeonCyan,
                        ),
                    )
                }
            }

            // Probe Method Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ProbeProtocol.entries.forEach { protocol ->
                    val selected = protocol == selectedProtocol
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectProtocol(protocol) },
                        modifier = Modifier.weight(1f),
                        label = {
                            Text(
                                text = protocol.label,
                                fontSize = 11.sp,
                                maxLines = 1,
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricViolet.copy(alpha = 0.2f),
                            selectedLabelColor = TextPrimary,
                            containerColor = ElevatedCard,
                            labelColor = TextSecondary,
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = SubtleBorder,
                            selectedBorderColor = ElectricViolet,
                        ),
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun DashboardHeader(metrics: PingMetrics) {
    val net = metrics.networkInfo
    val networkIcon: ImageVector = when {
        !net.isConnected -> Icons.Filled.SignalWifiOff
        net.connectionType == ConnectionType.WIFI -> Icons.Filled.SignalWifi4Bar
        else -> Icons.Filled.CellTower
    }
    val networkColor = if (net.isConnected) NeonCyan else SignalCrimson

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Bolt,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = "GAME PING MONITOR",
                    color = TextPrimary,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    letterSpacing = 0.6.sp,
                )
            }
            Text(
                text = if (metrics.isMonitoring) {
                    "1s Live Telemetry Active • ${net.transportDetail}"
                } else {
                    "Standby • ${net.transportDetail}"
                },
                color = TextSecondary,
                fontSize = 12.sp,
            )
        }

        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(networkColor.copy(alpha = 0.14f))
                .border(1.dp, networkColor.copy(alpha = 0.6f), RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 7.dp)
                .testTag("network_type_badge"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                imageVector = networkIcon,
                contentDescription = stringResource(R.string.cd_network_badge),
                tint = networkColor,
                modifier = Modifier.size(16.dp),
            )
            Text(
                text = net.connectionType.shortLabel,
                color = networkColor,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun MetricStatCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ElevatedCard)
            .border(1.dp, SubtleBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(accentColor),
            )
            Text(
                text = title,
                color = TextSecondary,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                letterSpacing = 0.7.sp,
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            color = TextMuted,
            fontSize = 11.sp,
        )
    }
}

@Composable
private fun PermissionReadinessCard(
    permissions: PermissionStatus,
    onRequestOverlay: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestPhoneState: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF17142B))
            .border(1.dp, ElectricViolet.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = Icons.Filled.WarningAmber,
                contentDescription = null,
                tint = SignalAmber,
                modifier = Modifier.size(18.dp),
            )
            Text(
                text = "SYSTEM PERMISSIONS SETUP",
                color = TextPrimary,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 0.6.sp,
            )
        }

        if (!permissions.overlayGranted) {
            PermissionRow(
                icon = Icons.Filled.Layers,
                title = "Floating Overlay Above Games",
                subtitle = "Required to show live ping over PUBG, Free Fire, eFootball",
                actionLabel = "Grant",
                onClick = onRequestOverlay,
                tag = "grant_overlay_permission_btn",
            )
        }
        if (!permissions.notificationsGranted) {
            PermissionRow(
                icon = Icons.Filled.NotificationsActive,
                title = "Foreground Service Notification",
                subtitle = "Keeps 1s monitoring alive & shows quick Stop controls",
                actionLabel = "Allow",
                onClick = onRequestNotifications,
                tag = "grant_notification_permission_btn",
            )
        }
        if (!permissions.phoneStateGranted) {
            PermissionRow(
                icon = Icons.Filled.Speed,
                title = "5G / 4G LTE / 3G Network Detection",
                subtitle = "Reads cellular radio type when switching off Wi-Fi",
                actionLabel = "Enable",
                onClick = onRequestPhoneState,
                tag = "grant_phone_permission_btn",
            )
        }
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String,
    onClick: () -> Unit,
    tag: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ElevatedCard)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = NeonCyan,
            modifier = Modifier.size(20.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
            )
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 11.sp,
            )
        }
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.testTag(tag),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, SolidColor(NeonCyan)),
        ) {
            Text(
                text = actionLabel,
                color = NeonCyan,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
        }
    }
}
