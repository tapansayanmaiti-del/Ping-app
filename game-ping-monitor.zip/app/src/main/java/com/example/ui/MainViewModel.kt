package com.example.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.example.PingMonitorApplication
import com.example.model.GameProfile
import com.example.model.OverlayConfig
import com.example.model.PingMetrics
import com.example.model.ProbeProtocol
import com.example.model.TestEndpoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PermissionStatus(
    val overlayGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val phoneStateGranted: Boolean = false,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as PingMonitorApplication).repository

    val metrics: StateFlow<PingMetrics> = repository.metrics
    val overlayConfig: StateFlow<OverlayConfig> = repository.overlayConfig
    val selectedEndpoint: StateFlow<TestEndpoint> = repository.selectedEndpoint
    val selectedProtocol: StateFlow<ProbeProtocol> = repository.selectedProtocol
    val selectedGameProfile: StateFlow<GameProfile> = repository.selectedGameProfile

    private val _permissions = MutableStateFlow(readPermissions())
    val permissions: StateFlow<PermissionStatus> = _permissions.asStateFlow()

    fun refreshPermissions() {
        _permissions.value = readPermissions()
        repository.refreshNetwork()
    }

    fun startMonitoring() = repository.startMonitoring()

    fun pauseMonitoring() = repository.pauseMonitoring()

    fun toggleMonitoring() = repository.toggleMonitoring()

    fun resetSessionStats() = repository.resetSessionStats()

    fun selectEndpoint(endpoint: TestEndpoint) = repository.selectEndpoint(endpoint)

    fun selectProtocol(protocol: ProbeProtocol) = repository.selectProtocol(protocol)

    fun selectGameProfile(profile: GameProfile) = repository.selectGameProfile(profile)

    fun updateOverlayConfig(transform: (OverlayConfig) -> OverlayConfig) {
        repository.updateOverlayConfig(transform)
    }

    private fun readPermissions(): PermissionStatus {
        val ctx = getApplication<Application>()
        val overlayGranted = Settings.canDrawOverlays(ctx)
        val notificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        val phoneStateGranted = ContextCompat.checkSelfPermission(
            ctx,
            Manifest.permission.READ_PHONE_STATE,
        ) == PackageManager.PERMISSION_GRANTED
        return PermissionStatus(
            overlayGranted = overlayGranted,
            notificationsGranted = notificationsGranted,
            phoneStateGranted = phoneStateGranted,
        )
    }
}
