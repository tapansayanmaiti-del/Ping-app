package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameProfile
import com.example.model.SupportedGames
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCrimson
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SignalGoodBlue
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GamesAndSetupScreen(
    selectedGameProfile: GameProfile,
    onSelectGameProfile: (GameProfile) -> Unit,
    onStartOverlayAndLaunchGame: (Intent) -> Unit,
    onOpenBatterySettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val packageManager = context.packageManager

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.SportsEsports,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = "SUPPORTED GAMES & SETUP",
                    color = TextPrimary,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                )
            }

            Text(
                text = "Apply tailored overlay layout presets for your favorite games. The floating monitor works over any Android game by measuring your phone's real-time internet connection.",
                color = TextSecondary,
                fontSize = 13.sp,
            )

            // Supported Games List
            SupportedGames.profiles.forEach { profile ->
                val isSelected = profile.id == selectedGameProfile.id
                val launchIntent = remember(profile.packageName) {
                    profile.packageName?.let { pkg ->
                        packageManager.getLaunchIntentForPackage(pkg)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(ElevatedCard)
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) NeonCyan else SubtleBorder,
                            shape = RoundedCornerShape(16.dp),
                        )
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.name,
                                color = TextPrimary,
                                fontFamily = ChakraPetchFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                            )
                            Text(
                                text = "${profile.category} • Target < ${profile.recommendedTargetMs} ms",
                                color = NeonCyan,
                                fontFamily = JetBrainsMonoFamily,
                                fontSize = 11.sp,
                            )
                        }
                        if (isSelected) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(NeonCyan.copy(alpha = 0.16f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(14.dp),
                                )
                                Text(
                                    text = "ACTIVE",
                                    color = NeonCyan,
                                    fontFamily = ChakraPetchFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                )
                            }
                        }
                    }

                    Text(
                        text = profile.placementTip,
                        color = TextSecondary,
                        fontSize = 12.sp,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = { onSelectGameProfile(profile) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("apply_profile_${profile.id}"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                SolidColor(if (isSelected) NeonCyan else SubtleBorder),
                            ),
                        ) {
                            Text(
                                text = if (isSelected) "Applied" else "Apply HUD Preset",
                                color = if (isSelected) NeonCyan else TextPrimary,
                                fontFamily = ChakraPetchFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                            )
                        }

                        if (launchIntent != null) {
                            Button(
                                onClick = {
                                    onSelectGameProfile(profile)
                                    onStartOverlayAndLaunchGame(launchIntent)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricViolet,
                                    contentColor = TextPrimary,
                                ),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "Play + HUD",
                                    fontFamily = ChakraPetchFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    }
                }
            }

            // Battery Optimization & Foreground Service Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ElevatedCard)
                    .border(1.dp, SubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = null,
                        tint = SignalEmerald,
                        modifier = Modifier.size(20.dp),
                    )
                    Text(
                        text = "BATTERY & BACKGROUND PROTECTION",
                        color = TextPrimary,
                        fontFamily = ChakraPetchFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                    )
                }

                Text(
                    text = "Uses lightweight 1-second TCP socket handshakes, automatically idles when offline, and uses a silent foreground service notification. If your phone aggressively closes overlays during long matches, set Game Ping Monitor to Unrestricted in Android battery settings.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )

                Button(
                    onClick = onOpenBatterySettings,
                    modifier = Modifier.fillMaxWidth().testTag("battery_settings_btn"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan.copy(alpha = 0.16f),
                        contentColor = NeonCyan,
                    ),
                ) {
                    Text(
                        text = "Open Android Battery Optimization Settings",
                        fontFamily = ChakraPetchFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                }
            }

            // Classification Guide
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ElevatedCard)
                    .border(1.dp, SubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = "STABILITY CLASSIFICATION THRESHOLDS",
                    color = TextPrimary,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                )
                ThresholdRow("EXCELLENT", "< 45 ms • Jitter < 12 ms • 0% Loss", SignalEmerald)
                ThresholdRow("GOOD", "45–89 ms • Jitter < 25 ms • < 5% Loss", SignalGoodBlue)
                ThresholdRow("UNSTABLE", "90–149 ms or Jitter >= 25 ms or >= 5% Loss", SignalAmber)
                ThresholdRow("HIGH LATENCY", ">= 150 ms or Packet Loss >= 15%", SignalCrimson)
                ThresholdRow("DISCONNECTED", "No active network or 3+ consecutive drops", TextMuted)
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ThresholdRow(
    label: String,
    criteria: String,
    color: Color,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            color = color,
            fontFamily = ChakraPetchFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
        )
        Text(
            text = criteria,
            color = TextSecondary,
            fontFamily = JetBrainsMonoFamily,
            fontSize = 10.5.sp,
        )
    }
}
