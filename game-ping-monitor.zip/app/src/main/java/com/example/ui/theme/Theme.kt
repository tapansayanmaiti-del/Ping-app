package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val GamingDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = ObsidianVoid,
    primaryContainer = GlassPanel,
    onPrimaryContainer = NeonCyan,
    secondary = ElectricViolet,
    onSecondary = TextPrimary,
    secondaryContainer = ColorTokens.VioletContainer,
    onSecondaryContainer = SoftLavender,
    tertiary = NeonBlue,
    onTertiary = TextPrimary,
    background = ObsidianVoid,
    onBackground = TextPrimary,
    surface = DeepSlate,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedCard,
    onSurfaceVariant = TextSecondary,
    outline = SubtleBorder,
    error = SignalCrimson,
    onError = TextPrimary,
)

private object ColorTokens {
    val VioletContainer = androidx.compose.ui.graphics.Color(0xFF231942)
}

val GamingShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
)

@Composable
fun GamePingTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = GamingDarkColorScheme,
        typography = AppTypography,
        shapes = GamingShapes,
        content = content,
    )
}
