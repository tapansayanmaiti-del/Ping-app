package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OverlayConfig
import com.example.model.PingMetrics
import com.example.ui.components.OverlayHudCard
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SignalCrimson
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun OverlayStudioScreen(
    metrics: PingMetrics,
    config: OverlayConfig,
    overlayPermissionGranted: Boolean,
    onUpdateConfig: ((OverlayConfig) -> OverlayConfig) -> Unit,
    onToggleMonitoring: () -> Unit,
    onToggleOverlay: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = "FLOATING OVERLAY STUDIO",
                    color = TextPrimary,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                )
            }

            Text(
                text = "Customize size, transparency, and HUD metrics. Drag the floating widget anywhere while gaming in portrait or landscape.",
                color = TextSecondary,
                fontSize = 13.sp,
            )

            // Interactive Live HUD Preview Stage
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF0A1628),
                                Color(0xFF191233),
                                Color(0xFF091B2C),
                            ),
                        ),
                    )
                    .border(1.dp, SubtleBorder, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "LIVE IN-GAME HUD PREVIEW",
                    color = TextMuted.copy(alpha = 0.55f),
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(14.dp),
                )

                OverlayHudCard(
                    metrics = metrics,
                    config = config,
                    onToggleExpand = {
                        onUpdateConfig { it.copy(isExpanded = !it.isExpanded) }
                    },
                    onToggleMonitoring = onToggleMonitoring,
                    onCloseOverlay = {
                        if (config.isOverlayActive) onToggleOverlay()
                    },
                )
            }

            // Launch / Stop Overlay CTA
            Button(
                onClick = onToggleOverlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("studio_launch_overlay_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (config.isOverlayActive) SignalCrimson else NeonCyan,
                    contentColor = if (config.isOverlayActive) TextPrimary else ObsidianVoid,
                ),
            ) {
                Icon(
                    imageVector = if (config.isOverlayActive) Icons.Filled.Close else Icons.Filled.Layers,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        config.isOverlayActive -> "Stop Floating Overlay"
                        overlayPermissionGranted -> "Launch Floating Overlay Over Games"
                        else -> "Grant Overlay Permission & Launch"
                    },
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                )
            }

            // Size & Transparency Controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ElevatedCard)
                    .border(1.dp, SubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                SliderControlRow(
                    label = "WIDGET SIZE",
                    valueLabel = "${(config.sizeScale * 100).roundToInt()}%",
                    value = config.sizeScale,
                    range = 0.75f..1.35f,
                    onValueChange = { scale ->
                        onUpdateConfig { it.copy(sizeScale = scale) }
                    },
                    tag = "overlay_size_slider",
                )

                SliderControlRow(
                    label = "TRANSPARENCY (OPACITY)",
                    valueLabel = "${(config.opacity * 100).roundToInt()}%",
                    value = config.opacity,
                    range = 0.35f..1.0f,
                    onValueChange = { alpha ->
                        onUpdateConfig { it.copy(opacity = alpha) }
                    },
                    tag = "overlay_opacity_slider",
                )
            }

            // Display Toggles
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ElevatedCard)
                    .border(1.dp, SubtleBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ToggleOptionRow(
                    title = "Expanded Telemetry Panel",
                    subtitle = "Disable to start as an ultra-compact pill badge",
                    checked = config.isExpanded,
                    onCheckedChange = { checked ->
                        onUpdateConfig { it.copy(isExpanded = checked) }
                    },
                )
                ToggleOptionRow(
                    title = "Show Jitter (ms)",
                    subtitle = "Display live connection stability variance",
                    checked = config.showJitter,
                    onCheckedChange = { checked ->
                        onUpdateConfig { it.copy(showJitter = checked) }
                    },
                )
                ToggleOptionRow(
                    title = "Show Packet Loss (%)",
                    subtitle = "Display dropped test probes percentage",
                    checked = config.showPacketLoss,
                    onCheckedChange = { checked ->
                        onUpdateConfig { it.copy(showPacketLoss = checked) }
                    },
                )
                ToggleOptionRow(
                    title = "Show Active Network (5G / 4G / Wi-Fi)",
                    subtitle = "Automatically updates when switching connections",
                    checked = config.showNetworkType,
                    onCheckedChange = { checked ->
                        onUpdateConfig { it.copy(showNetworkType = checked) }
                    },
                )
                ToggleOptionRow(
                    title = "Lock Overlay Position",
                    subtitle = "Prevents accidental dragging during intense touch gameplay",
                    checked = config.lockPosition,
                    onCheckedChange = { checked ->
                        onUpdateConfig { it.copy(lockPosition = checked) }
                    },
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SliderControlRow(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    tag: String,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = label,
                color = TextSecondary,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
            )
            Text(
                text = valueLabel,
                color = NeonCyan,
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier.testTag(tag),
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = DeepSlate,
            ),
        )
    }
}

@Composable
private fun ToggleOptionRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
            )
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 11.sp,
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianVoid,
                checkedTrackColor = NeonCyan,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = DeepSlate,
            ),
        )
    }
}
