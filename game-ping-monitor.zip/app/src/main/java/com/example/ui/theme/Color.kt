package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.model.ConnectionStability

val ObsidianVoid = Color(0xFF060A13)
val DeepSlate = Color(0xFF0B1120)
val ElevatedCard = Color(0xFF10192D)
val GlassPanel = Color(0xFF16223B)
val SubtleBorder = Color(0xFF243456)

val NeonCyan = Color(0xFF00E5FF)
val NeonBlue = Color(0xFF2979FF)
val ElectricViolet = Color(0xFF8B5CF6)
val SoftLavender = Color(0xFFC4B5FD)

val SignalEmerald = Color(0xFF00E676)
val SignalGoodBlue = Color(0xFF38BDF8)
val SignalAmber = Color(0xFFFFB300)
val SignalCrimson = Color(0xFFFF3D57)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

fun stabilityColor(stability: ConnectionStability): Color {
    return when (stability) {
        ConnectionStability.EXCELLENT -> SignalEmerald
        ConnectionStability.GOOD -> SignalGoodBlue
        ConnectionStability.UNSTABLE -> SignalAmber
        ConnectionStability.HIGH_LATENCY -> SignalCrimson
        ConnectionStability.DISCONNECTED -> TextMuted
    }
}
