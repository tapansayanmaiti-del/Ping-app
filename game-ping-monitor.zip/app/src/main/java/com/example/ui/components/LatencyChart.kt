package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PingSample
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.ElevatedCard
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCrimson
import com.example.ui.theme.SubtleBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.max

@Composable
fun LatencyChart(
    samples: List<PingSample>,
    modifier: Modifier = Modifier,
) {
    val maxPlotMs = max(120, (samples.mapNotNull { it.rttMs }.maxOrNull() ?: 100) + 20)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ElevatedCard)
            .border(1.dp, SubtleBorder, RoundedCornerShape(18.dp))
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "REAL-TIME LATENCY WAVEFORM (60s)",
                color = TextSecondary,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                letterSpacing = 0.8.sp,
            )
            Text(
                text = "${samples.size} samples",
                color = NeonCyan,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 11.sp,
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (samples.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(124.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "Start monitoring to capture 1-second live latency telemetry",
                    color = TextMuted,
                    fontSize = 12.sp,
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(124.dp),
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val topPad = 8.dp.toPx()
                    val bottomPad = 8.dp.toPx()
                    val chartH = (h - topPad - bottomPad).coerceAtLeast(1f)

                    // 45ms and 90ms reference lines
                    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                    listOf(45 to NeonCyan.copy(alpha = 0.25f), 90 to SignalAmber.copy(alpha = 0.28f)).forEach { (ms, color) ->
                        if (ms <= maxPlotMs) {
                            val y = topPad + chartH * (1f - (ms.toFloat() / maxPlotMs.toFloat()))
                            drawLine(
                                color = color,
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = dashEffect,
                            )
                        }
                    }

                    val count = samples.size
                    val stepX = if (count > 1) w / (count - 1).toFloat() else w

                    val linePath = Path()
                    val fillPath = Path()
                    var hasActiveSegment = false
                    var lastX = 0f
                    var segmentStartX = 0f

                    samples.forEachIndexed { index, sample ->
                        val x = if (count == 1) w / 2f else index * stepX
                        val rtt = sample.rttMs
                        if (sample.success && rtt != null) {
                            val norm = (rtt.toFloat() / maxPlotMs.toFloat()).coerceIn(0f, 1f)
                            val y = topPad + chartH * (1f - norm)
                            if (!hasActiveSegment) {
                                linePath.moveTo(x, y)
                                fillPath.moveTo(x, topPad + chartH)
                                fillPath.lineTo(x, y)
                                segmentStartX = x
                                hasActiveSegment = true
                            } else {
                                linePath.lineTo(x, y)
                                fillPath.lineTo(x, y)
                            }
                            lastX = x
                        } else {
                            // Packet drop marker
                            drawLine(
                                color = SignalCrimson.copy(alpha = 0.8f),
                                start = Offset(x, topPad),
                                end = Offset(x, topPad + chartH),
                                strokeWidth = 2.dp.toPx(),
                            )
                            drawCircle(
                                color = SignalCrimson,
                                radius = 3.5.dp.toPx(),
                                center = Offset(x, topPad + 4.dp.toPx()),
                            )
                            if (hasActiveSegment) {
                                fillPath.lineTo(lastX, topPad + chartH)
                                fillPath.lineTo(segmentStartX, topPad + chartH)
                                fillPath.close()
                                hasActiveSegment = false
                            }
                        }
                    }

                    if (hasActiveSegment) {
                        fillPath.lineTo(lastX, topPad + chartH)
                        fillPath.lineTo(segmentStartX, topPad + chartH)
                        fillPath.close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                NeonCyan.copy(alpha = 0.28f),
                                ElectricViolet.copy(alpha = 0.08f),
                                Color.Transparent,
                            ),
                        ),
                    )

                    drawPath(
                        path = linePath,
                        brush = Brush.horizontalGradient(listOf(NeonCyan, ElectricViolet)),
                        style = Stroke(
                            width = 2.4.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round,
                        ),
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = "Scale: 0 - ${maxPlotMs} ms",
                color = TextMuted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 10.sp,
            )
            Text(
                text = "Red lines = Packet Loss",
                color = TextMuted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 10.sp,
            )
        }
    }
}
