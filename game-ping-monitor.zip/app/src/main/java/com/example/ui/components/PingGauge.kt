package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.PingMetrics
import com.example.ui.theme.ChakraPetchFamily
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.stabilityColor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PingGauge(
    metrics: PingMetrics,
    modifier: Modifier = Modifier,
) {
    val activeColor by animateColorAsState(
        targetValue = stabilityColor(metrics.stability),
        animationSpec = tween(350),
        label = "gauge_color",
    )

    val normalizedTarget = when {
        !metrics.networkInfo.isConnected -> 0f
        metrics.currentPingMs == null -> 0.08f
        else -> (metrics.currentPingMs.toFloat() / 180f).coerceIn(0.08f, 1f)
    }

    val sweepFraction by animateFloatAsState(
        targetValue = normalizedTarget,
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "gauge_sweep",
    )

    val pulseTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_alpha",
    )

    val cdText = stringResource(R.string.cd_ping_gauge)

    Box(
        modifier = modifier
            .size(204.dp)
            .semantics { contentDescription = cdText },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(204.dp)) {
            val strokeWidth = 14.dp.toPx()
            val inset = strokeWidth / 2f + 12.dp.toPx()
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val arcTopLeft = Offset(inset, inset)
            val center = Offset(size.width / 2f, size.height / 2f)

            // Outer ambient neon glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        activeColor.copy(alpha = if (metrics.isMonitoring) pulseAlpha * 0.45f else 0.12f),
                        ElectricViolet.copy(alpha = 0.08f),
                        Color.Transparent,
                    ),
                    center = center,
                    radius = size.minDimension * 0.52f,
                ),
            )

            // Subtle tick marks
            val outerRadius = size.minDimension / 2f - 4.dp.toPx()
            val innerTickRadius = outerRadius - 6.dp.toPx()
            val tickCount = 36
            for (i in 0 until tickCount) {
                val angleDeg = 135.0 + (270.0 / (tickCount - 1)) * i
                val rad = angleDeg * PI / 180.0
                val start = Offset(
                    x = center.x + (innerTickRadius * cos(rad)).toFloat(),
                    y = center.y + (innerTickRadius * sin(rad)).toFloat(),
                )
                val end = Offset(
                    x = center.x + (outerRadius * cos(rad)).toFloat(),
                    y = center.y + (outerRadius * sin(rad)).toFloat(),
                )
                drawLine(
                    color = if (i % 5 == 0) NeonCyan.copy(alpha = 0.35f) else TextMuted.copy(alpha = 0.22f),
                    start = start,
                    end = end,
                    strokeWidth = if (i % 5 == 0) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }

            // Track arc
            drawArc(
                color = Color(0xFF1A2744),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )

            // Live latency sweep arc
            if (sweepFraction > 0f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(NeonCyan, activeColor, ElectricViolet, NeonCyan),
                        center = center,
                    ),
                    startAngle = 135f,
                    sweepAngle = 270f * sweepFraction,
                    useCenter = false,
                    topLeft = arcTopLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                text = "INTERNET PING",
                color = TextSecondary,
                fontFamily = ChakraPetchFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
                letterSpacing = 1.4.sp,
            )

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center,
            ) {
                val pingValue = when {
                    !metrics.networkInfo.isConnected -> "--"
                    metrics.currentPingMs != null -> metrics.currentPingMs.toString()
                    metrics.isMonitoring -> "..."
                    else -> "--"
                }
                Text(
                    text = pingValue,
                    color = TextPrimary,
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 46.sp,
                )
                Text(
                    text = " ms",
                    color = activeColor,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(activeColor.copy(alpha = 0.14f))
                    .border(1.dp, activeColor.copy(alpha = 0.6f), RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(activeColor),
                )
                Text(
                    text = metrics.stability.label,
                    color = activeColor,
                    fontFamily = ChakraPetchFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.8.sp,
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${metrics.activeEndpointHost} • ${metrics.activeProtocolLabel}",
                color = TextMuted,
                fontFamily = JetBrainsMonoFamily,
                fontSize = 10.sp,
            )
        }
    }
}
