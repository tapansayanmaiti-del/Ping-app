package com.example

import com.example.model.ConnectionStability
import com.example.model.ConnectionType
import com.example.model.NetworkStatusInfo
import com.example.model.PingMetricsCalculator
import com.example.model.PingSample
import com.example.model.PresetEndpoints
import com.example.model.ProbeProtocol
import com.example.network.PingProber
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PingMetricsCalculatorTest {

    private val connected5g = NetworkStatusInfo(
        isConnected = true,
        connectionType = ConnectionType.CELLULAR_5G,
        transportDetail = "5G Mobile",
    )

    @Test
    fun compute_calculatesRealMinMaxAvgJitterAndLoss() {
        val samples = listOf(
            PingSample(1000L, 30, true, "1.1.1.1", "TCP"),
            PingSample(2000L, 40, true, "1.1.1.1", "TCP"),
            PingSample(3000L, 34, true, "1.1.1.1", "TCP"),
            PingSample(4000L, null, false, "1.1.1.1", "TCP", "Timeout"),
        )

        val metrics = PingMetricsCalculator.compute(
            isMonitoring = true,
            allSamples = samples,
            networkInfo = connected5g,
            activeEndpoint = PresetEndpoints.cloudflare,
            activeProtocol = ProbeProtocol.TCP_HANDSHAKE,
        )

        assertNull(metrics.currentPingMs)
        assertEquals(30, metrics.minPingMs)
        assertEquals(40, metrics.maxPingMs)
        assertEquals(35, metrics.avgPingMs)
        // |40-30| + |34-40| = 10 + 6 = 16 / 2 = 8 ms
        assertEquals(8, metrics.jitterMs)
        assertEquals(25f, metrics.packetLossPercent, 0.01f)
        assertEquals(1, metrics.consecutiveFailures)
        assertEquals(ConnectionStability.HIGH_LATENCY, metrics.stability)
    }

    @Test
    fun classifyStability_returnsExcellentForLowLatencyZeroLoss() {
        val stability = PingMetricsCalculator.classifyStability(
            networkConnected = true,
            currentPingMs = 28,
            avgPingMs = 31,
            jitterMs = 4,
            packetLossPercent = 0f,
            consecutiveFailures = 0,
            totalProbes = 20,
        )
        assertEquals(ConnectionStability.EXCELLENT, stability)
    }

    @Test
    fun classifyStability_returnsDisconnectedWhenOfflineOrThreeDrops() {
        assertEquals(
            ConnectionStability.DISCONNECTED,
            PingMetricsCalculator.classifyStability(
                networkConnected = false,
                currentPingMs = 20,
                avgPingMs = 20,
                jitterMs = 2,
                packetLossPercent = 0f,
                consecutiveFailures = 0,
                totalProbes = 5,
            ),
        )
        assertEquals(
            ConnectionStability.DISCONNECTED,
            PingMetricsCalculator.classifyStability(
                networkConnected = true,
                currentPingMs = null,
                avgPingMs = 35,
                jitterMs = 4,
                packetLossPercent = 30f,
                consecutiveFailures = 3,
                totalProbes = 10,
            ),
        )
    }

    @Test
    fun parseIcmpLatencyMs_extractsPingOutputCorrectly() {
        val sampleOutput = "64 bytes from 1.1.1.1: icmp_seq=1 ttl=57 time=24.7 ms"
        assertEquals(25, PingProber.parseIcmpLatencyMs(sampleOutput))
        assertNull(PingProber.parseIcmpLatencyMs("100% packet loss"))
    }
}
