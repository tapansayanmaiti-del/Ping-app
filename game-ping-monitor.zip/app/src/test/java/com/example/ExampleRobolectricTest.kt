package com.example

import android.content.Context
import android.telephony.TelephonyManager
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.model.ConnectionType
import com.example.network.NetworkMonitor
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w412dp-h915dp-420dpi")
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun appName_matchesGamePingMonitor() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Game Ping Monitor", appName)
    }

    @Test
    fun dashboard_rendersPrimaryControlsAndNavigatesTabs() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("network_type_badge").assertIsDisplayed()
        composeRule.onNodeWithTag("monitor_toggle_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("overlay_toggle_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("nav_monitor").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_overlay").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_games").assertIsDisplayed()

        // Navigate to Overlay Studio tab and verify preview & launch CTA
        composeRule.onNodeWithTag("nav_overlay").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("studio_launch_overlay_btn").performScrollTo().assertIsDisplayed()

        // Navigate to Games & Setup tab
        composeRule.onNodeWithTag("nav_games").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("apply_profile_efootball").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun cellularGenerationMapping_detects5g4g3gCorrectly() {
        assertEquals(
            ConnectionType.CELLULAR_5G,
            NetworkMonitor.mapNetworkType(TelephonyManager.NETWORK_TYPE_NR),
        )
        assertEquals(
            ConnectionType.CELLULAR_4G,
            NetworkMonitor.mapNetworkType(TelephonyManager.NETWORK_TYPE_LTE),
        )
        assertEquals(
            ConnectionType.CELLULAR_3G,
            NetworkMonitor.mapNetworkType(TelephonyManager.NETWORK_TYPE_HSPAP),
        )
    }
}
